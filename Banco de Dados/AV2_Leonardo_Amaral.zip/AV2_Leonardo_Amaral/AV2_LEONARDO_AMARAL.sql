CREATE DATABASE IF NOT EXISTS SPOTIFY;
USE SPOTIFY;

/*QUESTÃO 01*/

CREATE TABLE IF NOT EXISTS MUSICA(
    id INT PRIMARY KEY NOT NULL,
    letra TEXT(65535),
    duracao INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cont BLOB NOT NULL,
    img BLOB,
    album VARCHAR(50),
    genero VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS USUARIO(
    email VARCHAR(100) PRIMARY KEY NOT NULL,
    nome VARCHAR(100) NOT NULL,
    nasc DATE NOT NULL,
    ult_msk INT,
    FOREIGN KEY (ult_msk) REFERENCES MUSICA(id)
);

CREATE TABLE IF NOT EXISTS CARTAO(
    numero INT PRIMARY KEY NOT NULL,
    cv INT NOT NULL,
    bandeira ENUM('VISA', 'MASTER', 'ELO')
);

CREATE TABLE IF NOT EXISTS PAGAMENTO(
    id INT PRIMARY KEY NOT NULL,
    valor FLOAT NOT NULL,
    mes_ref TINYINT NOT NULL,
    ano_ref INT NOT NULL,
    u_email VARCHAR(100) NOT NULL,
    c_numero INT NOT NULL,
    FOREIGN KEY (u_email) REFERENCES USUARIO(email),
    FOREIGN KEY (c_numero) REFERENCES CARTAO(numero)
);

CREATE TABLE IF NOT EXISTS PLAYLIST(
    id INT PRIMARY KEY NOT NULL,
    nome VARCHAR(100) NOT NULL,
    publica BOOLEAN,
    u_email VARCHAR(100) NOT NULL,
    FOREIGN KEY (u_email) REFERENCES USUARIO(email)
);

CREATE TABLE IF NOT EXISTS AMIGOS(
    u_email1 VARCHAR(100),
    u_email2 VARCHAR(100),
    PRIMARY KEY(u_email1, u_email2),
    FOREIGN KEY (u_email1) REFERENCES USUARIO(email),
    FOREIGN KEY (u_email2) REFERENCES USUARIO(email)
);

CREATE TABLE IF NOT EXISTS ARTISTA(
    u_email VARCHAR(100) PRIMARY KEY,
    FOREIGN KEY (u_email) REFERENCES USUARIO(email),
);

CREATE TABLE IF NOT EXISTS AUTOR(
    a_email VARCHAR(100),
    m_id INT,
    PRIMARY KEY(a_email, m_id),
    FOREIGN KEY (a_email) REFERENCES ARTISTA(u_email),
    FOREIGN KEY (m_id) REFERENCES MUSICA(id),
);

CREATE TABLE IF NOT EXISTS PLAYLIST_MUSICA(
    p_id INT,
    m_id INT,
    PRIMARY KEY(p_id, m_id),
    FOREIGN KEY (p_id) REFERENCES PLAYLIST(id),
    FOREIGN KEY (m_id) REFERENCES MUSICA(id),
);

/*QUESTÃO 02*/

/*a)*/
INSERT INTO USUARIO VALUES('leo@gmail.com', 'Leo', '1999-09-18', NULL);
INSERT INTO USUARIO VALUES('guga@gmail.com', 'Guga', '2000-04-12', NULL);
INSERT INTO USUARIO VALUES('tania@gmail.com', 'Tania', '1964-09-20', NULL);

INSERT INTO CARTAO VALUES(1, 001, 'VISA');
INSERT INTO CARTAO VALUES(2, 002, 'MASTER');
INSERT INTO CARTAO VALUES(3, 003, 'ELO');

INSERT INTO PAGAMENTO VALUES(1, 20.00, 8, 2022, 'leo@gmail.com', 1);
INSERT INTO PAGAMENTO VALUES(2, 54.00, 9, 2022, 'leo@gmail.com', 1);
INSERT INTO PAGAMENTO VALUES(3, 12.00, 10, 2022, 'leo@gmail.com', 1);

INSERT INTO PAGAMENTO VALUES(4, 33.00, 8, 2022, 'guga@gmail.com', 2);
INSERT INTO PAGAMENTO VALUES(5, 22.00, 9, 2022, 'guga@gmail.com', 2);
INSERT INTO PAGAMENTO VALUES(6, 10.00, 10, 2022, 'guga@gmail.com', 2);

INSERT INTO PAGAMENTO VALUES(7, 07.00, 8, 2022, 'tania@gmail.com', 3);
INSERT INTO PAGAMENTO VALUES(8, 25.00, 9, 2022, 'tania@gmail.com', 3);
INSERT INTO PAGAMENTO VALUES(9, 30.00, 10, 2022, 'tania@gmail.com', 3);

/*b)*/
INSERT INTO MUSICA(id, letra, duracao, nome, album, genero)
    VALUES(1, '...', 180, 'Californication', '...', 'Rock');
INSERT INTO MUSICA(id, letra, duracao, nome, album, genero)
    VALUES(2, '...', 180, 'Purple Haze', '...', 'Rock');
INSERT INTO MUSICA(id, letra, duracao, nome, album, genero)
    VALUES(3, '...', 180, 'Alive', '...', 'Eletronica');

INSERT INTO ARTISTA VALUES('leo@gmail.com');
INSERT INTO ARTISTA VALUES('guga@gmail.com');
INSERT INTO ARTISTA VALUES('tania@gmail.com');

INSERT INTO AUTOR VALUES('leo@gmail.com', 1);
INSERT INTO AUTOR VALUES('leo@gmail.com', 2);

INSERT INTO AUTOR VALUES('guga@gmail.com', 2);
INSERT INTO AUTOR VALUES('guga@gmail.com', 3);

INSERT INTO AUTOR VALUES('tania@gmail.com', 1);
INSERT INTO AUTOR VALUES('tania@gmail.com', 3);

/*c)*/
INSERT INTO PLAYLIST VALUES(1, "Musicas", TRUE, 'leo@gmail.com');

INSERT INTO PLAYLIST_MUSICA VALUES(1, 1);
INSERT INTO PLAYLIST_MUSICA VALUES(1, 2);

/*QUESTÃO 03*/

/*a)*/
SELECT U.nome, C.bandeira, P.valor,P.mes_ref, P.ano_ref
    FROM USUARIO AS U,
    FROM CARTAO AS C,
    FROM PAGAMENTO AS P
    WHERE U.email = P.u_email AND P.c_numero = C.numero;

/*b)*/
SELECT PM.p_id, P.nome, P.publica, P.u_email, PM.m_id, M.letra, M.duracao, M.nome, M.cont, M.img, M.album, M.genero
    FROM PLAYLIST AS P,
    FROM MUSICA AS M,
    FROM PLAYLIST_MUSICA AS PM
    WHERE P.id = PM.p_id AND PM.m_id = M.id;

/*c)*/
SELECT AVG(duracao)
    FROM MUSICA
    WHERE genero = 'Rock';
